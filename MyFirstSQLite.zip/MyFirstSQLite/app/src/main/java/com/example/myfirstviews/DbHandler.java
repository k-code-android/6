package com.example.myfirstviews;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.HashMap;
import android.database.Cursor;

public class DbHandler extends SQLiteOpenHelper {
    //Database version
    private static final int DB_VERSION = 1;
    //Database name
    private static final String DB_NAME = "contactdb";
    //Contacts table name
    private static final String TABLE_Contacts = "contactdetails";
    //Contacts table structure
    private static final String KEY_ID = "id";
    private static final String KEY_USERID = "uid";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_CONFIRM_PASSWORD = "confirmPassword";
    private static final String KEY_NAME = "name";
    private static final String KEY_DOB = "dob";
    private static final String KEY_GENDER = "gender";
    private static final String KEY_EMAIL = "email";
    public DbHandler(Context context){
        super(context,DB_NAME, null, DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        String CREATE_TABLE = "CREATE TABLE " + TABLE_Contacts + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_USERID + " TEXT," + KEY_PASSWORD + " TEXT,"
                + KEY_CONFIRM_PASSWORD + " TEXT," + KEY_NAME + " TEXT," + KEY_DOB + " TEXT,"
                + KEY_GENDER +" TEXT," + KEY_EMAIL + " TEXT" + ")";
        db.execSQL(CREATE_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        // Drop older table if exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Contacts);
        // Create tables again
        onCreate(db);
    }


    // Adding new Contact
    void insertUserDetails(String userID,String password, String confirmPassword,String name, String dob, String gender, String email){
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        //Create a new map of values, where column names are the keys
        ContentValues cv = new ContentValues();
        cv.put(KEY_USERID,userID);
        cv.put(KEY_PASSWORD,password);
        cv.put(KEY_CONFIRM_PASSWORD,password);
        cv.put(KEY_NAME, name);
        cv.put(KEY_DOB, dob);
        cv.put(KEY_GENDER, gender);
        cv.put(KEY_EMAIL, email);
        // Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(TABLE_Contacts,null, cv);
        db.close();
    }
    // Get User Details
    public ArrayList<HashMap<String, String>> GetUsers(){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HashMap<String, String>> userList = new ArrayList<>();
        String query = "SELECT uid,name,dob,gender,email FROM "+ TABLE_Contacts;
        Cursor cursor = db.rawQuery(query,null);
        while (cursor.moveToNext()){
            HashMap<String,String> user = new HashMap<>();
            user.put("userid",cursor.getString(cursor.getColumnIndex(KEY_USERID)));
            user.put("name",cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            user.put("dob",cursor.getString(cursor.getColumnIndex(KEY_DOB)));
            user.put("gender",cursor.getString(cursor.getColumnIndex(KEY_GENDER)));
            user.put("email",cursor.getString(cursor.getColumnIndex(KEY_EMAIL)));
            userList.add(user);
        }
        return  userList;
    }
    // Update User Details
    public int UpdateUserDetails(String userID, String name, String dob, String gender, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_USERID,userID);
        cv.put(KEY_NAME, name);
        cv.put(KEY_DOB, dob);
        cv.put(KEY_GENDER, gender);
        cv.put(KEY_EMAIL, email);
        int count = db.update(TABLE_Contacts, cv, KEY_USERID+" = ?",new String[]{String.valueOf(userID)});
        return  count;
    }
}
