package com.example.myfirstviews;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.view.Gravity;
import android.widget.EditText;
import android.os.Bundle;
import android.widget.Toast;
import java.util.Calendar;

public class UpdateContact extends AppCompatActivity {
    EditText contactId,name,password,confirmPassword,dob,emailText;
    RadioButton male,female;
    Button btn_update;
    String gender;
    DatePickerDialog dobPicker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_contact);
        contactId= findViewById(R.id.id);
        Button btn_update = findViewById(R.id.update);
        name= findViewById(R.id.name);
        dob= findViewById(R.id.dob);
        male= findViewById(R.id.radioButtonMale);
        female= findViewById(R.id.radioButtonFemale);
        emailText= findViewById(R.id.email);
        final RadioGroup rgp = (RadioGroup) findViewById(R.id.radioGroup2);
        Bundle bundle = getIntent().getExtras();
        contactId.setText(bundle.getString("id"));
        name.setText(bundle.getString("name"));
        dob.setText(bundle.getString("dob"));
       // contactId.setText(bundle.getString("id"));
        emailText.setText(bundle.getString("email"));
        gender=bundle.getString("gender");
        if(gender.equals("Male"))
        {
            male.setChecked(true);
            female.setChecked(false);
        }
        else
        {
            male.setChecked(false);
            female.setChecked(true);
        }
        dob.setInputType(InputType.TYPE_NULL);
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);

                // date picker dialog
                dobPicker = new DatePickerDialog(UpdateContact.this, AlertDialog.THEME_HOLO_LIGHT,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                //("dayOfMonth" + "/" + (monthOfYear + 1) + "/" + year);

                                dob.setText((dayOfMonth + "/" + (monthOfYear + 1) + "/" + year));

                            }
                        }, year, month, day);

                dobPicker.show();

            }

        });



        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton selectedRadioButton = (RadioButton) findViewById(rgp.getCheckedRadioButtonId());
                try {


                    DbHandler dbHandler = new DbHandler(UpdateContact.this);
                    dbHandler.UpdateUserDetails(contactId.getText().toString(), name.getText().toString(), dob.getText().toString(), selectedRadioButton.getText().toString(), emailText.getText().toString());
                    // initiate a Toast with message and duration
                    Toast toastMessage = Toast.makeText(getApplicationContext(), "Record updated", Toast.LENGTH_SHORT);
                    toastMessage.setGravity(Gravity.BOTTOM | Gravity.START, 150, 0);
                    toastMessage.show(); // display the Toast
                } catch (Exception ex) {
                    Toast toastMessage = Toast.makeText(getApplicationContext(), "Error in updating", Toast.LENGTH_SHORT);
                }
            }
        });


    }

}

