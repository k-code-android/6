package com.example.myfirstviews;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.widget.DatePicker;
import android.app.DatePickerDialog;
import java.util.Calendar;
import android.content.Intent;
public class MainActivity extends AppCompatActivity {

    String pwdValue,confirmPwdValue,submitMethod;
    DatePickerDialog dobPicker;

    private EditText userID,name,dob,emailText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Button View
        Button submitButton = findViewById(R.id.submit);
        Button viewAll= findViewById(R.id.view);
        // User id
        final EditText userID = findViewById(R.id.id);
        //Password Text
        final EditText password = findViewById(R.id.password);
        //Confirm Password Text
        final EditText confirmPassword = findViewById(R.id.confirmPassword);
        //Name
        name = findViewById(R.id.name);
        // Radio button
        final RadioGroup rg = (RadioGroup) findViewById(R.id.radioGroup2);
        //email
        emailText = findViewById(R.id.email);

        dob = findViewById(R.id.dob);
        dob.setInputType(InputType.TYPE_NULL);
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);

                // date picker dialog
                dobPicker = new DatePickerDialog(MainActivity.this,AlertDialog.THEME_HOLO_LIGHT,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                 //("dayOfMonth" + "/" + (monthOfYear + 1) + "/" + year);

                                dob.setText((dayOfMonth + "/" + (monthOfYear + 1) + "/" + year));

                            }
                        }, year, month, day);

                dobPicker.show();

            }

        });
       submitButton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
              final String[] submitLocation = getResources().getStringArray(R.array.submit_type);

               pwdValue =password.getText().toString();
               confirmPwdValue = confirmPassword.getText().toString();
               if(!pwdValue.equals(confirmPwdValue) || pwdValue.isEmpty())
               {
                   AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                   // set title
                   alertDialogBuilder.setTitle("Error");
                   // set dialog message
                   alertDialogBuilder
                           .setMessage("Password and confirm password must be the same.")
                           .setCancelable(false)
                           .setPositiveButton("Ok",new DialogInterface.OnClickListener() {
                               public void onClick(DialogInterface dialog,int id) {
                                   // if this button is clicked, close
                                   // current activity
                                   // Main2Activity.this.finish();
                                   dialog.cancel();
                               }
                           });
                   AlertDialog alertDialog = alertDialogBuilder.create();

                   // show it
                   alertDialog.show();
                   Button positiveButton = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE);
                   positiveButton.setTextColor(Color.parseColor("#FF0B8B42"));

               }
               else {



                      AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                           MainActivity.this)
                           .setTitle(R.string.alert_dialog_title)
                           .setItems(submitLocation, new OnClickListener() {

                                       @Override
                                       public void onClick(DialogInterface dialog,
                                                           int which) {
                                           submitMethod=submitLocation[which];
                                           String uid = userID.getText().toString();
                                           String pwd = password.getText().toString();
                                           String confPwd = password.getText().toString();
                                           String username = name.getText().toString()+"\n";
                                           String date_of_birth = dob.getText().toString();
                                           RadioButton selectedRadioButton = (RadioButton) findViewById(rg.getCheckedRadioButtonId());
                                           String gender = selectedRadioButton.getText().toString();
                                           String email = emailText.getText().toString();
                                           DbHandler dbHandler = new DbHandler(MainActivity.this);
                                           dbHandler.insertUserDetails(uid, pwd, confPwd, username, date_of_birth, gender, email);

                                           // initiate a Toast with message and duration
                                           Toast toastMessage = Toast.makeText(getApplicationContext(),submitMethod, Toast.LENGTH_LONG);
                                           toastMessage.setGravity(Gravity.TOP | Gravity.START, 100, 0);
                                           toastMessage.show(); // display the Toast

                                       }
                                   })

                           .setNegativeButton(R.string.btn_Cancel, new OnClickListener() {

                               @Override
                               public void onClick(DialogInterface dialog, int which) {
                                   dialog.dismiss();
                               }
                           });
                   AlertDialog dialog = alertDialogBuilder.create();
                    dialog.show();

               }
           }
       });

       viewAll.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

              Intent intent = new Intent(MainActivity.this,ViewAllUsers.class);
               startActivity(intent);
           }
       });

    }

}
