package com.example.myfirstviews;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.HashMap;

public class CustomAdapter extends BaseAdapter{
    private ArrayList<HashMap<String, String>> contactList;
    Context rContext;
    private LayoutInflater layoutInflater;
    public CustomAdapter(Context aContext, ArrayList<HashMap<String, String>> userList) {

        this.contactList = userList;
        layoutInflater = LayoutInflater.from(aContext);
        this.rContext=aContext;
    }


    @Override
    public int getCount() {
        return contactList.size();
    }
    @Override
    public Object getItem(int position) {

       return contactList.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    public View getView(int position, View v, ViewGroup vg) {
        ViewValueHolder holder;
        if (v == null) {
            v = layoutInflater.inflate(R.layout.activity_list_view, null);
            holder = new ViewValueHolder();

            holder.userId = (TextView) v.findViewById(R.id.userId);
            holder.name = (TextView) v.findViewById(R.id.name);
            holder.dob = (TextView) v.findViewById(R.id.dob);
            holder.gender = (TextView) v.findViewById(R.id.gender);
            holder.email = (TextView) v.findViewById(R.id.email);
            v.setTag(holder);
        } else {
            holder = (ViewValueHolder) v.getTag();
        }
        holder.userId.setText(contactList.get(position).get("userid").toString());
        holder.name.setText(contactList.get(position).get("name").toString());
        holder.dob.setText(contactList.get(position).get("dob").toString());
        holder.gender.setText(contactList.get(position).get("gender").toString());
        holder.email.setText(contactList.get(position).get("email").toString());

        return v;
    }
    static class ViewValueHolder {
        TextView userId;
        TextView name;
        TextView dob;
        TextView gender;
        TextView email;
    }
}
