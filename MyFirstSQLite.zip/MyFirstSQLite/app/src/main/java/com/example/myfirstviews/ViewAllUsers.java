package com.example.myfirstviews;

import java.util.ArrayList;
import java.util.HashMap;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;



public class ViewAllUsers extends Activity implements AdapterView.OnItemClickListener {

    ListView simpleList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_users);
        simpleList = (ListView) findViewById(R.id.simpleListView);
        DbHandler db = new DbHandler(this);
        ArrayList<HashMap<String, String>> userList = db.GetUsers();
        CustomAdapter adapter = new CustomAdapter(getApplicationContext(), userList);
        simpleList.setAdapter(adapter);
        simpleList.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {



        Intent intent = new Intent(ViewAllUsers.this,UpdateContact.class);
        Bundle contactBundle = new Bundle();
        //Add  data to bundle
        contactBundle.putString("id",((TextView) view.findViewById(R.id.userId)).getText().toString());
        contactBundle.putString("name",((TextView) view.findViewById(R.id.name)).getText().toString());
        contactBundle.putString("dob",((TextView) view.findViewById(R.id.dob)).getText().toString());
        contactBundle.putString("gender",((TextView) view.findViewById(R.id.gender)).getText().toString());
        contactBundle.putString("email",((TextView) view.findViewById(R.id.email)).getText().toString());
        intent.putExtras(contactBundle);
        startActivity(intent);


    }
}
